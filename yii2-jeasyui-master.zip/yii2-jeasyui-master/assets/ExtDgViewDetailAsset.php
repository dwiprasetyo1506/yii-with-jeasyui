<?php

/**
 * Implement jQuery EasyUI v.1.5.4 GPL Edition on Yii2
 * since    : v.2.0.0-alpha4
 * author   : sheillendra
 * date     : 2018-02-25
 * website  : sheillendra.com
 */

namespace sheillendra\jeasyui\assets;

class ExtDgViewDetailAsset extends ExtDgViewAsset {

    public $js = ['datagrid-detailview.js'];

}
