v2.0.0-beta, Sep 2017
-----------
* break code from v1.0.0 remake code
* add simulation / example
* remove widget in php, write code in javascript to minimize delay in browser
* add more dynamic setting in ```layouts/_init_login``` & ```layouts/_init_logged```
  

v1.0.0-stable
-------------
* add gii


Beta
----

* 12/10/14 23:35 property plugin need depedency plugin, fixed
* tree plugin,added
* init
